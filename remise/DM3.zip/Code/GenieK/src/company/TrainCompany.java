package company;

public class TrainCompany extends Company {


}
