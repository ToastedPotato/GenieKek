package company;

public class CruiseCompany extends Company {

}
