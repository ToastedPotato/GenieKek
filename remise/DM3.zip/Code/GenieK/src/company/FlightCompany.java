package company;

public class FlightCompany extends Company {

}
