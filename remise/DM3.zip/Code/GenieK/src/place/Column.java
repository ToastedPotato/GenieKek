package place;

public enum Column {
    A,
    B,
    C,
    D,
    E,
    F,
    G,
    H,
    I,
    J
}
