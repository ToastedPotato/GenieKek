package transport;

public class Boat extends Transport {

    public Boat(Class<?> sectionClass) {
        super(sectionClass);
    }
}