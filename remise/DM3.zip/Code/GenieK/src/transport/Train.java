package transport;

public class Train extends Transport {

    public Train(Class<?> sectionType) {
        super(sectionType);
    }
}
