package transport;

public class Plane extends Transport {

    public Plane(Class<?> sectionClass) {
        super(sectionClass);
    }
}