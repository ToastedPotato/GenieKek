package station;

public class Aeroport extends Station {

    private int nbTerminal;

    public void setNbTerminal(int nbTerminal) {
        this.nbTerminal = nbTerminal;
    }

    public int getNbTerminal() {
        return nbTerminal;
    }
}
