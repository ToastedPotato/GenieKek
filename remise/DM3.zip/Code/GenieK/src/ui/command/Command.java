package ui.command;

public interface Command{

    boolean execute();
    
    boolean unexecute();
}
