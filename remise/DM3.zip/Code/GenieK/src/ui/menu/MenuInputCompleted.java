package ui.menu;

public interface MenuInputCompleted {

    void onCompleted(MenuInput inputs);

}
