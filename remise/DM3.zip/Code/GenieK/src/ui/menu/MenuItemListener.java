package ui.menu;

public interface MenuItemListener {

    void onSelect();

}
