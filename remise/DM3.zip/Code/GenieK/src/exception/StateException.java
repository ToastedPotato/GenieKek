package exception;

public class StateException extends SystemException {

    public StateException(String message) {
        super(message);
    }
}
