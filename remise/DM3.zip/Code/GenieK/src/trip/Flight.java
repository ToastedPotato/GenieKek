package trip;

import station.Station;

public class Flight extends Trip {

    /*public Flight(String id, int number, Station depart, Station arrive, String idCompany) {
        super(id, number, depart, arrive, idCompany);
    }*/

}
